package rs.raf.projekat2.marko_gajin_RM8517.data.datasources

import io.reactivex.Observable
import retrofit2.http.*
import rs.raf.projekat2.marko_gajin_RM8517.data.models.api.EmployeesResponse

interface EmployeeDataSource {

    @GET("employees")
    fun getAll() : Observable<EmployeesResponse>


}