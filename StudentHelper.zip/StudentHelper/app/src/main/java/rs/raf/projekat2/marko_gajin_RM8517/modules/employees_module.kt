package rs.raf.projekat2.marko_gajin_RM8517.modules

import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module
import rs.raf.projekat2.marko_gajin_RM8517.data.datasources.EmployeeDataSource
import rs.raf.projekat2.marko_gajin_RM8517.data.repositories.EmployeeRepository
import rs.raf.projekat2.marko_gajin_RM8517.data.repositories.EmployeeRepositoryImpl
import rs.raf.projekat2.marko_gajin_RM8517.presentation.viewmodels.MainViewModel

val employeesModule = module {

    viewModel { MainViewModel(get()) }

    single<EmployeeRepository> { EmployeeRepositoryImpl(get()) }

    single<EmployeeDataSource> { create(get()) }

}