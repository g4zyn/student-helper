package rs.raf.projekat2.marko_gajin_RM8517.data.models.ui

data class Employee(
    val id: String,
    val name: String,
    val salary: String,
    val age: String
)