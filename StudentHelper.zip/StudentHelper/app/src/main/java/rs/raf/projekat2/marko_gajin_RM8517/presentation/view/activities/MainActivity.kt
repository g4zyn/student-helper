package rs.raf.projekat2.marko_gajin_RM8517.presentation.view.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import org.koin.androidx.viewmodel.ext.android.viewModel
import rs.raf.projekat2.marko_gajin_RM8517.R
import rs.raf.projekat2.marko_gajin_RM8517.presentation.contracts.MainContract
import rs.raf.projekat2.marko_gajin_RM8517.presentation.contracts.ScheduleContract
import rs.raf.projekat2.marko_gajin_RM8517.presentation.viewmodels.MainViewModel
import rs.raf.projekat2.marko_gajin_RM8517.presentation.viewmodels.ScheduleViewModel
import timber.log.Timber

class MainActivity : AppCompatActivity(R.layout.activity_main) {

    private val mainViewModel: MainContract.ViewModel by viewModel<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        init()
    }

    private fun init() {
        initObservers()
    }

    private fun initObservers() {
        /* DOHVATANJE SVIH ZAPOSLENIH */
        mainViewModel.employees.observe(this, Observer {
            Timber.e("Got employees $it")
            // Kada dobijemo listu svih korisnika sa servera, hocemo da dohvatimo posebno
            // podatke o prvom zaposlenom
            /* API NE RADI !!! */
//            mainViewModel.getEmployee(it[0].id)
        })
        mainViewModel.getEmployees()
    }

//    private val scheduleViewModel: ScheduleContract.ViewModel by viewModel<ScheduleViewModel>()
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        init()
//    }
//
//    private fun init() {
//        initObservers()
//    }
//
//    private fun initObservers() {
//
//        scheduleViewModel.schedule.observe(this, Observer {
//            Timber.e("Got schedule $it")
//        })
//        scheduleViewModel.getSchedule()
//
//    }

}
